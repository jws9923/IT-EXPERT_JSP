package itexpert.chap10;

import java.sql.Timestamp;

/**
 * ����� �� �ϳ��� ��� ��
 *
 * @author kenu
 */

public class ArticleBean {
    private int seq;
    private String name;
    private String email;
    private String homepage;
    private String subject;
    private String content;
    private String password;
    private Timestamp logtime;

    /**
     * Returns the content.
     * @return String
     */
    public String getContent() {
        return content;
    }

    /**
     * Returns the email.
     * @return String
     */
    public String getEmail() {
        return email;
    }

    /**
     * Returns the homepage.
     * @return String
     */
    public String getHomepage() {
        return homepage;
    }

    /**
     * Returns the logtime.
     * @return Timestamp
     */
    public Timestamp getLogtime() {
        return logtime;
    }

    /**
     * Returns the name.
     * @return String
     */
    public String getName() {
        return name;
    }

    /**
     * Returns the password.
     * @return String
     */
    public String getPassword() {
        return password;
    }

    /**
     * Returns the seq.
     * @return int
     */
    public int getSeq() {
        return seq;
    }

    /**
     * Returns the subject.
     * @return String
     */
    public String getSubject() {
        return subject;
    }

    /**
     * Sets the content.
     * @param content The content to set
     */
    public void setContent(String content) {
        this.content = content;
    }

    /**
     * Sets the email.
     * @param email The email to set
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * Sets the homepage.
     * @param homepage The homepage to set
     */
    public void setHomepage(String homepage) {
        this.homepage = homepage;
    }

    /**
     * Sets the logtime.
     * @param logtime The logtime to set
     */
    public void setLogtime(Timestamp logtime) {
        this.logtime = logtime;
    }

    /**
     * Sets the name.
     * @param name The name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Sets the password.
     * @param password The password to set
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * Sets the seq.
     * @param seq The seq to set
     */
    public void setSeq(int seq) {
        this.seq = seq;
    }

    /**
     * Sets the subject.
     * @param subject The subject to set
     */
    public void setSubject(String subject) {
        this.subject = subject;
    }

}
