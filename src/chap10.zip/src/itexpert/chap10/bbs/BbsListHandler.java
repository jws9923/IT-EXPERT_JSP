package itexpert.chap10.bbs;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import itexpert.common.DsConn;

/**
 * @author kenu
 *
 * ��ü �Խù� ������ ����� ���ϴ� �׼Ǻ�
 */
public class BbsListHandler {
    final static String QUERY_COUNT =
        "SELECT COUNT(*) FROM BOARD";
    final static String QUERY_LIST =
        "SELECT * FROM (SELECT /*+ INDEX_DESC(BOARD IDX_BOARD_REF) */ ROWNUM RSEQ, SEQ, REF, STEP, LEV, NAME, EMAIL, HOMEPAGE, SUBJECT, LOGTIME, HIT, PSEQ, REPLY FROM BOARD WHERE ROWNUM <= ?) A WHERE A.RSEQ > ?";
    private int pageSize = 10; // �⺻ ������ ��ϼ� 10��
    private int cpage = 1;     // ������ ���۹�ȣ 1

    /**
     * �������� �´� �Խù� ����� ��ȯ�Ѵ�. ��������ȣ��
     * @return Collection
     * @throws SQLException
     */
    public Collection getList() throws SQLException {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        // ����� ��� ����Ʈ
        List list = new ArrayList();
        try {

            conn = DsConn.getConnection();
            if(conn==null) {
                throw new SQLException("Ŀ�ؼ��� ������ �� �����ϴ�.");
            }

            // ������ ������ �Խù� ��ȣ
            int endNo = pageSize * cpage;
            pstmt = conn.prepareStatement(QUERY_LIST);
            pstmt.setInt(1, endNo);
            pstmt.setInt(2, endNo - pageSize);
            rs = pstmt.executeQuery();

            // �Խù����� BbsArticleBean ��ü�� �����ؼ�
            // ������ ä�� �ڿ� list �� �߰�.
            while(rs.next()) {
                BbsArticleBean ab = new BbsArticleBean();
                ab.setSeq (rs.getInt("seq"));
                ab.setRef (rs.getInt("ref"));
                ab.setStep(rs.getInt("step"));
                ab.setLev (rs.getInt("lev"));
                ab.setName(rs.getString("name"));
                //��Ͽ��� email, homepage, ������ �����ߴ�.
                //ab.setEmail(rs.getString("email"));
                //ab.setHomepage(rs.getString("homepage"));
                ab.setSubject(rs.getString("subject"));
                //ab.setContent( rs.getString("content"));
                ab.setLogtime(rs.getTimestamp("logtime"));
                ab.setHit  (rs.getInt("hit"));
                ab.setPseq (rs.getInt("pseq"));
                ab.setReply(rs.getInt("reply"));
                list.add(ab);
            }

        // db ���� �ݱ�
        } catch (SQLException e) {
            throw e;
        } finally {
            conn.close();
        }
        return list;
    }
    /**
     * �Խù� ���� ��ȯ�Ѵ�.
     * @return int
     */
    public int getTotal() throws SQLException {
        int total = 0;
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {

            conn = DsConn.getConnection();
            if(conn==null) {
                throw new SQLException("Ŀ�ؼ��� ������ �� �����ϴ�.");
            }

            // �Խù� ī��Ʈ
            pstmt = conn.prepareStatement(QUERY_COUNT);
            rs = pstmt.executeQuery();
            if(rs.next()) {
                total = rs.getInt(1);
            }
            rs.close();
            pstmt.close();

        // db ���� �ݱ�
        } catch (SQLException e) {
            throw e;
        } finally {
            conn.close();
        }
        return total;
    }

    /**
     * Sets the cpage.
     * @param cpage The cpage to set
     */
    public void setCpage(int cpage) {
        if(cpage < 1) cpage = 1;
        this.cpage = cpage;
    }

    /**
     * Sets the pageSize.
     * @param pageSize The pageSize to set
     */
    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    /**
     * Returns the cpage.
     * @return int
     */
    public int getCpage() {
        return cpage;
    }

    /**
     * Returns the pageSize.
     * @return int
     */
    public int getPageSize() {
        return pageSize;
    }

}
