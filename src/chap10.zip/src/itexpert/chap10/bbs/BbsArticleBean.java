package itexpert.chap10.bbs;

import itexpert.chap10.ArticleBean;

/**
 * @author kenu
 * �亯�� �Խ��� �Խù��� �����ϴ� ��
 */
public class BbsArticleBean extends ArticleBean {
    private int ref;   // �׷��ȣ
    private int step;  // �׷쳻 ����
    private int lev;   // �亯�� ����
    private int hit;   // ��ȸ��
    private int html;  // content �� html �ҽ� 0:TEXT 1:HTML+BR 2:HTML
    private int pseq;  // ���۹�ȣ
    private int reply; // ��ۼ�

    /**
     * Returns the hit.
     * @return int
     */
    public int getHit() {
        return hit;
    }

    /**
     * Returns the lev.
     * @return int
     */
    public int getLev() {
        return lev;
    }

    /**
     * Returns the ref.
     * @return int
     */
    public int getRef() {
        return ref;
    }

    /**
     * Returns the step.
     * @return int
     */
    public int getStep() {
        return step;
    }

    /**
     * @return int
     */
    public int getHtml() {
        return html;
    }

    /**
     * Returns the pseq.
     * @return int
     */
    public int getPseq() {
        return pseq;
    }

    /**
     * Returns the reply.
     * @return int
     */
    public int getReply() {
        return reply;
    }

    /**
     * Sets the hit.
     * @param hit The hit to set
     */
    public void setHit(int hit) {
        this.hit = hit;
    }

    /**
     * Sets the lev.
     * @param lev The lev to set
     */
    public void setLev(int lev) {
        this.lev = lev;
    }

    /**
     * Sets the ref.
     * @param ref The ref to set
     */
    public void setRef(int ref) {
        this.ref = ref;
    }

    /**
     * Sets the step.
     * @param step The step to set
     */
    public void setStep(int step) {
        this.step = step;
    }

    /**
     * content �� html �ҽ� 0:TEXT 1:HTML+BR 2:HTML
     * @param html The html to set
     */
    public void setHtml(int html) {
        this.html = html;
    }

    /**
     * Sets the pseq.
     * @param pseq The pseq to set
     */
    public void setPseq(int pseq) {
        this.pseq = pseq;
    }

    /**
     * Sets the reply.
     * @param reply The reply to set
     */
    public void setReply(int reply) {
        this.reply = reply;
    }

}
