package itexpert.chap10;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import itexpert.common.CommonUtil;
import itexpert.common.DsConn;

/**
 * @author kenu
 *
 * ���� db�� �Է�
 */
public class WriteHandler extends ArticleBean {

    final static String QUERY_INSERT =
        "INSERT INTO GUESTBOOK (SEQ, NAME, EMAIL, HOMEPAGE, SUBJECT, CONTENT, PASSWORD, LOGTIME) VALUES (SEQ_GUESTBOOK.NEXTVAL,?,?,?,?,?,?,SYSDATE)";
    /**
     * Article ���� �޾Ƽ� db �� �� ���
     * @throws SQLException
     */
    public void doWrite() throws SQLException {

        Connection conn = null;
        PreparedStatement pstmt = null;


        try {
            // ������ �Է�
            conn = DsConn.getConnection();
            pstmt = conn.prepareStatement(QUERY_INSERT);
            pstmt.setString(1, CommonUtil.toKor(this.getName    ()));
            pstmt.setString(2, this.getEmail   ());
            pstmt.setString(3, CommonUtil.toKor(this.getHomepage()));
            pstmt.setString(4, CommonUtil.toKor(this.getSubject ()));
            pstmt.setString(5, CommonUtil.toKor(this.getContent ()));
            pstmt.setString(6, this.getPassword());

            int result = pstmt.executeUpdate();
            pstmt.close();

            if (result == 0) {
                throw new SQLException("���� ��ϵ��� �ʾҽ��ϴ�.");
            }

            // db ���� �ݱ�
        } catch (SQLException e) {
            throw e;
        } finally {
            try {
                conn.close();
            } catch (SQLException e) {
            }
        }
    }

}
