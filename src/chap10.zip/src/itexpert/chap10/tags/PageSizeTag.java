package itexpert.chap10.tags;

import javax.servlet.jsp.JspTagException;
import javax.servlet.jsp.tagext.*;

/**
 * pageSize �±�; �������� �Խù� ���� �޾Ƶ��δ�.
 */
public class PageSizeTag extends BodyTagSupport {

    public int doAfterBody() throws JspTagException {
        PageNavigationTag parent =
            (PageNavigationTag) findAncestorWithClass(this,
                PageNavigationTag.class);
        if (parent == null) {
            throw new JspTagException("pageSize�� PageNavigation�ȿ� �־�� �˴ϴ�.");
        }
        int size = Integer.parseInt(getBodyContent().getString().trim());
        parent.setPageSize(size);

        return SKIP_BODY;
    }

}
