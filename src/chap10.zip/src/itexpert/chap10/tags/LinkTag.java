package itexpert.chap10.tags;

import javax.servlet.jsp.JspTagException;
import javax.servlet.jsp.tagext.*;

/**
 * link �±�; ������ ��ȣ�� �� �ּҸ� �޾Ƶ��δ�.
 */
public class LinkTag extends BodyTagSupport {

    public int doAfterBody() throws JspTagException {
        PageNavigationTag parent =
            (PageNavigationTag) findAncestorWithClass(this,
                PageNavigationTag.class);
        if (parent == null) {
            throw new JspTagException("link�� PageNavigation�ȿ� �־�� �˴ϴ�.");
        }
        String link = getBodyContent().getString().trim();
        parent.setLink(link);

        return SKIP_BODY;
    }

}
