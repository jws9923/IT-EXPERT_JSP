package itexpert.chap10.tags;

import javax.servlet.jsp.JspTagException;
import javax.servlet.jsp.tagext.*;

/**
 * total �±�; ��ü �Խù� ������ �޾ƿ´�.
 */
public class TotalTag extends BodyTagSupport {

    public int doAfterBody() throws JspTagException {
        PageNavigationTag parent =
            (PageNavigationTag) findAncestorWithClass(this,
                PageNavigationTag.class);
        if (parent == null) {
            throw new JspTagException("total�� PageNavigation�ȿ� �־�� �˴ϴ�.");
        }
        int total = Integer.parseInt(getBodyContent().getString().trim());
        parent.setTotal(total);

        return SKIP_BODY;
    }

}
