package itexpert.chap10.tags;

import java.io.IOException;

import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.TagSupport;

/**
 * ������ �׺���̼��� ǥ���ϴ� �±�
 *
 * @author kenu
 *
 */
public class PageNavigationTag extends TagSupport {
    private int cpage;
    private int total;
    private int pageSize;
    private String link;

    public int doStartTag() {
        return EVAL_BODY_INCLUDE;
    }

    public int doEndTag() {
    //    ��ü������
        int totalPage = (total-1)/pageSize + 1;
    //    ����10��, ����10��
    //    ���� ������ ������ 0 �̸� ����10�� ����
        int prev10 = (int)Math.floor((cpage-1) / 10.0) * 10;
    //    ���� ù������ totalPage ���� ũ�� ����10�� ����
        int next10 = prev10 + 11;
        StringBuffer sbuf = new StringBuffer();

        sbuf.append("<a href=\"").append(link)
            .append("&cpage=1").append("\">top</a>\n");

        if(prev10 > 0) {
            sbuf.append("<a href=\"").append(link)
                .append("&cpage=").append(prev10)
                .append("\">����10��</a>\n");
        } // end if ����10��

        for (int i=1+prev10; i<next10 && i<=totalPage; i++ ) {
            if (i==cpage) {
                sbuf.append(" [<b>").append(i).append("</b>] ");
            } else {
                sbuf.append(" [<a href=\"").append(link)
                    .append("&cpage=").append(i).append("\">")
                    .append(i).append("</a>] ");
            } // end if ���������� ��ũ����
        } // end for

        if(totalPage >= next10) {
            sbuf.append("<a href=\"").append(link)
                .append("&cpage=").append(next10)
                .append("\">����10��</a>\n");
        } // end if ����10��

        sbuf.append("<a href=\"").append(link)
            .append("&cpage=").append(totalPage)
            .append("\">bottom</a>\n");
        JspWriter out = pageContext.getOut();
        try {
            out.print(sbuf.toString());
        } catch (IOException e) {
            System.out.println( e.toString() );
        }
        return EVAL_PAGE;
    }
    /**
     * Sets the cpage.
     * @param cpage The cpage to set
     */
    public void setCpage(int cpage) {
        this.cpage = cpage;
    }

    /**
     * Sets the pageSize.
     * @param pageSize The pageSize to set
     */
    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    /**
     * Sets the total.
     * @param total The total to set
     */
    public void setTotal(int total) {
        this.total = total;
    }

    /**
     * Sets the link.
     * @param link The link to set
     */
    public void setLink(String link) {
        this.link = link;
    }

}
