package itexpert.chap13.buy;

import itexpert.chap13.exceptions.ShopDAOException;

public class OrderDAOFactory {

    public static OrderDAO getDAO(String dbType) throws ShopDAOException {
        if (dbType.equals("oracle")) {
            return new OraOrderDAOImpl();
        } else {
            throw new ShopDAOException("dbType: " + dbType + " NOT IMPLEMENTED");  
        }
     }
}
