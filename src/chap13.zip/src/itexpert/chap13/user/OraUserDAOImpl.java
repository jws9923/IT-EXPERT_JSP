package itexpert.chap13.user;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.struts.action.ActionForm;
import org.apache.commons.beanutils.PropertyUtils;
import org.apache.log4j.Logger;
import itexpert.chap13.util.DBResource;
import itexpert.chap13.util.ShopConstant;
import itexpert.chap13.exceptions.ShopDAOException;

public class OraUserDAOImpl implements UserDAO {
    
    Logger log = Logger.getLogger(OraUserDAOImpl.class); 

    public int checkUser(ActionForm form, HttpServletRequest request, 
                         HttpServletResponse response) throws ShopDAOException {
        int checkResult = 0; 
        DBResource db = new DBResource();
        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            // ���󿡼� id�� passwd�� �����´�.
            String id = (String) PropertyUtils.getSimpleProperty(form, "id");
            String passwd = (String) PropertyUtils.getSimpleProperty(form, "passwd");
            log.debug(id + "/" + passwd); // ����׸� ���� �α׸� �����.
            if (id.equals("") || passwd.equals("")) {
                return ShopConstant.BLANK_NOTPERMMITED;
            }
            String sql = "SELECT passwd, name, address, phone FROM member WHERE id=?";
            con = db.getConnection(ShopConstant.SHOP_DATASOURCE);
            pstmt = con.prepareStatement(sql);
            pstmt.setString(1, id);
            rs = pstmt.executeQuery();
            if (rs.next()) {
                // ����Ÿ���̽��� �ִ� �Ͱ� �Է��� �н����尡 ��ġ�ϴ��� Ȯ��
                if (rs.getString("passwd").equals(passwd)) {
                    UserInfoBean userInfo = new UserInfoBean();
                    userInfo.setId(id);
                    userInfo.setName(rs.getString("name"));
                    userInfo.setAddress(rs.getString("address"));
                    userInfo.setPhone(rs.getString("phone"));
                    HttpSession session = request.getSession();
                    // session ������ UserInfoBean ��ü�� �����Ѵ�.
                    session.setAttribute("userInfo", userInfo);
                } else {
                    checkResult = ShopConstant.PASSWD_MISMATCH;
                }    
            } else {
                checkResult = ShopConstant.ID_NOTEXIST;
                log.debug("Else checkResult: " + checkResult);
            }
        } catch (Exception e) {
            log.error(e.toString());
            throw new ShopDAOException(e.getMessage());
        } finally {
            db.close(rs, pstmt, con);
        }
        return checkResult;
    }

    public int registerUser(ActionForm form,HttpServletRequest request, 
                            HttpServletResponse response) throws ShopDAOException {
        int checkResult = 0; 
        DBResource db = new DBResource();
        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            String id = (String) PropertyUtils.getSimpleProperty(form, "id");
            String passwd = (String) PropertyUtils.getSimpleProperty(form, "passwd");
            String name = (String) PropertyUtils.getSimpleProperty(form, "name");
            String address = (String) PropertyUtils.getSimpleProperty(form, "address");
            String phone = (String) PropertyUtils.getSimpleProperty(form, "phone");
            // �Է°����� ���������� �������� Ȯ���� �ʿ䰡 �־� �α׸� �����.
            log.debug(id + "/" + passwd + "/" + name + "/" + address + "/" + phone);
            if (id.equals("") || passwd.equals("") || name.equals("") || address.equals("") || phone.equals("")) {
                return ShopConstant.BLANK_NOTPERMMITED;
            }
            log.debug("default check executed");
            String sql = "SELECT COUNT(id) FROM member WHERE id=?";
            con = db.getConnection(ShopConstant.SHOP_DATASOURCE);
            pstmt = con.prepareStatement(sql);
            pstmt.setString(1, id);
            rs = pstmt.executeQuery();
            log.info("count(id) executed");
            rs.next();
            // ����Ÿ���̽��� �̹� ��ϵ� ���̵� �ִ� ���
            if (rs.getInt(1) > 0) {
                checkResult = ShopConstant.ID_DUPLICATE;
            } else {
                sql = "INSERT INTO member VALUES (?, ?, ?, ?, ?)";
                pstmt = con.prepareStatement(sql);
                log.debug("setter begin");
                pstmt.setString(1, id);
                pstmt.setString(2, passwd);
                pstmt.setString(3, name);
                pstmt.setString(4, address);
                pstmt.setString(5, phone);
                log.debug("setter end");
                pstmt.executeUpdate(); // ����Ÿ���̽��� �ݿ�

                UserInfoBean userInfo = new UserInfoBean();    
                PropertyUtils.copyProperties(userInfo, form); 
                /**
                 * PropertyUtils.copyProperties �޼ҵ带 ����Ͽ� ���ʿ����� �κ�
                userInfo.setId(id);
                userInfo.setName(name);
                userInfo.setAddress(address);
                userInfo.setPhone(phone);
                */
                HttpSession session = request.getSession();
                
                session.setAttribute("userInfo", userInfo);
            }
        } catch (Exception e) {
            log.error(e.toString());
            throw new ShopDAOException(e.getMessage());
        } finally {
            db.close(rs, pstmt, con);
        }
        return checkResult;
    }
}