CREATE TABLE orderlist (
       id VARCHAR2(20) NOT NULL, 
       isbn VARCHAR2(30) NOT NULL,
       quantity NUMBER(4)NOT NULL
);

COMMIT;
