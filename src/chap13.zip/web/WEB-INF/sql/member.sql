CREATE TABLE member (
       id VARCHAR2(20) PRIMARY KEY,
       passwd VARCHAR2(20) NOT NULL,
       name VARCHAR2(20) NOT NULL,
       address VARCHAR2(50) NOT NULL,
       phone VARCHAR2(15) NOT NULL
);

COMMIT;