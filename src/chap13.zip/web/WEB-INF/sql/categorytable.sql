CREATE TABLE categorytable (
       code NUMBER(2) PRIMARY KEY,
       category VARCHAR2(40)
);

INSERT INTO categorytable VALUES(10, 'Programming Language');
INSERT INTO categorytable VALUES(20, 'Web Development');
INSERT INTO categorytable VALUES(30, 'Enterprise Solutions');
INSERT INTO categorytable VALUES(40, 'Operating System');
INSERT INTO categorytable VALUES(50, 'Computer Hardware');
INSERT INTO categorytable VALUES(60, 'Computer Software');

COMMIT;