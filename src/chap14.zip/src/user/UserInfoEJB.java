package itexpert.chap14.ejbs.session;
import itexpert.chap14.ejbs.entity.*;
import javax.ejb.SessionBean;
import javax.naming.InitialContext;
import javax.ejb.SessionContext;
import javax.ejb.EJBException;
import javax.ejb.FinderException;
import javax.ejb.CreateException;
import itexpert.chap13.user.UserInfoBean;

public class UserInfoEJB implements SessionBean {
	public UserInfoBean getUserInfo(String id, String passwd)
	throws PasswordMismatchException, IDNotFoundException {
		UserInfoBean userInfo = null;
		LocalMemberHome home = null;
		try {
			home = (LocalMemberHome)new InitialContext().lookup("java:comp/env/MemberEJB");
		} catch(Exception e) {
			e.printStackTrace();
			throw new EJBException(e.getMessage());
		}
		try {
			System.out.println("trying find member ejb");
			LocalMember member = home.findByPrimaryKey(id);
			System.out.println("looked up member ejb");
			if(passwd.equals(member.getPasswd())) {
				userInfo = new UserInfoBean();
				userInfo.setId(member.getId());
				userInfo.setName(member.getName());
				userInfo.setPhone(member.getPhone());
				userInfo.setAddress(member.getAddress());
			} else {
				throw new PasswordMismatchException("Member ID with : " +
				id + " exists but didn't match with passwd " + passwd);
			}
		} catch(FinderException e) {
			e.printStackTrace();
			throw new IDNotFoundException("Member ID with : " + id + " doesn't exist");
		}
		return userInfo;
	}
	public UserInfoBean createUser(String id, String passwd, String name, String address, String phone) {
		UserInfoBean userInfo = null;
		LocalMemberHome home = null;
		try {
			home = (LocalMemberHome)new InitialContext().lookup("java:comp/env/MemberEJB");
		} catch(Exception e) {
			e.printStackTrace();
			throw new EJBException(e.getMessage());
		}		
		try {
			LocalMember member = home.create(id, passwd, name, address, phone);
			userInfo = new UserInfoBean();
			userInfo.setId(member.getId());
			userInfo.setName(member.getName());
			userInfo.setPhone(member.getPhone());
			userInfo.setAddress(member.getAddress());
		} catch(CreateException e) {
			e.printStackTrace();
		}
		return userInfo;
	}
	public void ejbCreate() {}

	//////// SessionBean interface Implementation/////
	public void ejbRemove() throws EJBException{}
	public void ejbActivate() throws EJBException {}
	public void ejbPassivate() throws EJBException {}
	public void setSessionContext(SessionContext ctx) throws EJBException {}
}