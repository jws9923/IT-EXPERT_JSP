package itexpert.chap14.ejbs.session;
import java.rmi.RemoteException;
import javax.ejb.CreateException;
import javax.ejb.EJBHome;
public interface UserInfoHome extends EJBHome {
	public UserInfo create () throws RemoteException, CreateException;
}