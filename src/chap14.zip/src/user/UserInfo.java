package itexpert.chap14.ejbs.session;
import javax.ejb.EJBObject;
import java.rmi.RemoteException;
import itexpert.chap13.user.UserInfoBean;
public interface UserInfo extends EJBObject {
	public UserInfoBean getUserInfo(String id, String passwd)
	throws RemoteException, PasswordMismatchException, IDNotFoundException;
	public UserInfoBean createUser(String id, String passwd, String name, String address, String phone)
	throws RemoteException;

}
		