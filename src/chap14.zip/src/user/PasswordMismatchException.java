package itexpert.chap14.ejbs.session;
public class PasswordMismatchException extends Exception {
	public PasswordMismatchException() {}
	public PasswordMismatchException(String reason) {
		super(reason);
	}
}