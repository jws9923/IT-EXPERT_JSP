package itexpert.chap14.ejbs.session;
public class IDNotFoundException extends Exception {
	public IDNotFoundException() {}
	public IDNotFoundException(String reason) {
		super(reason);
	}
}