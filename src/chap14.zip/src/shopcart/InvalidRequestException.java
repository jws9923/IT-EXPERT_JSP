package itexpert.chap14.ejbs;
public class InvalidRequestException extends Exception {
	public InvalidRequestException (String reason) {
		super(reason);
	}
	public InvalidRequestException() {
		this("Unkown Reason:Shopping Cart EJB");
	}
}