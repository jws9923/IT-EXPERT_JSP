package itexpert.chap14.ejbs;
import java.util.*;
import javax.ejb.EJBObject;
import java.rmi.RemoteException;
public interface ShoppingCart extends EJBObject {
	public void addItem(String title) throws RemoteException;
	public void removeItem(String title) throws InvalidRequestException, RemoteException;
	public Vector getItems() throws RemoteException;
	public String getName()throws RemoteException;
}
