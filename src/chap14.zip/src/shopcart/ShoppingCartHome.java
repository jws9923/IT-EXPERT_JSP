package itexpert.chap14.ejbs;
import java.rmi.RemoteException;
import javax.ejb.CreateException;
import javax.ejb.EJBHome;

public interface ShoppingCartHome extends EJBHome {
	ShoppingCart create(String name) throws RemoteException, CreateException;
	ShoppingCart create() throws RemoteException, CreateException;
}
