package itexpert.chap14.client;
import itexpert.chap14.ejbs.*;
import java.util.*;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.rmi.PortableRemoteObject;
public class ShoppingCartClient {
	public static void main(String[] args) {
		try {
			if(args[0] != null) {
				Properties props = System.getProperties();
				props.put("org.omg.CORBA.ORBInitialHost", args[0]);
				props.put("org.omg.CORBA.ORBInitialPort", "1050");
				System.setProperties(props);
			}
			InitialContext ctx = new InitialContext();	
			Object obj = ctx.lookup("ShoppingCartEJB");
			ShoppingCartHome home = 
			(ShoppingCartHome)PortableRemoteObject.narrow(obj, 
			ShoppingCartHome.class);
			ShoppingCart cart1 = home.create("�����");
			ShoppingCart cart2 = home.create();
			ShoppingCart cart3 = home.create("��ȸ��");
			cart1.addItem("Java Servlet ���� ����");
			cart2.addItem("Perfect Java Server Pages");
			cart3.addItem("Java Programming Language");
			showItems(cart1);
			showItems(cart2);
			showItems(cart3);
			
			cart1.removeItem("Java Servlet ���� ����");
			cart2.removeItem("Enterprise JavaBeans");
			
			cart1.remove();
			cart2.remove();
			cart3.remove();
		} catch (InvalidRequestException e) {
			System.err.println("���� ���� ���� ǰ���� ���� �� �������ϴ�.");
			System.err.println("Exception: " + e.getMessage());
		} catch (Exception e) {
			System.err.println("Caught an unexpected exception!");
			e.printStackTrace();
		}
	}
	public static void showItems(ShoppingCart cart) throws java.rmi.RemoteException {
		String name = cart.getName();
		System.out.println(name + " ���� ����īƮ ���� �Դϴ�");
		Vector items = cart.getItems();
		Enumeration enum = items.elements();
		while (enum.hasMoreElements()) {
			String title = (String) enum.nextElement();
			System.out.println(title);
		}
	}
} 