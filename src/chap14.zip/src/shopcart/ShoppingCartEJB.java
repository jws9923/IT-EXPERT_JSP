package itexpert.chap14.ejbs;
import java.util.*;
import javax.ejb.*;
public class ShoppingCartEJB implements SessionBean {
	String name;
	Vector items = new Vector();
	SessionContext ctx;
	public void ejbCreate() throws CreateException {
		this.name = "Guest";
	}
	public void ejbCreate(String name) throws CreateException {
		if (name == null) {
			throw new CreateException("�̸��� Null�� �ɼ� �����ϴ�.");
		}else {
			this.name = name;
		}
		items = new Vector();
	}
	public void addItem(String title) {
		items.addElement(title);
	}
	public void removeItem(String title) 
	throws InvalidRequestException {
		if(!items.removeElement(title)) {
			throw new InvalidRequestException("�����Ͻ÷��� ������ " + title + " �� ����īƮ�� ���������ʽ��ϴ�.");
		}  
	}
	public Vector getItems() {
		return items;
	}
	public String getName() {
		return this.name;
	}
	public ShoppingCartEJB() {}
	public void ejbRemove() { System.out.println ("ejbRemove()"); }
	public void ejbActivate() {}
	public void ejbPassivate() {}
	public void setSessionContext(SessionContext sc) {
		this.ctx = sc;
	}	
}