package itexpert.chap13.buy;

import itexpert.chap13.exceptions.ShopDAOException;
import itexpert.chap13.util.ShopConstant;
public class OrderDAOFactory {

    public static OrderDAO getDAO(String dbType) throws ShopDAOException {
        if (dbType.equals("oracle")) {
        	return new OraOrderDAOImpl();
        } else if(dbType.equals(ShopConstant.EJB_DAO)) {
			return new EJBOrderDAOImpl("java:comp/env/OrderProcEJB");
        } else {
        	throw new ShopDAOException("dbType: " + dbType + " NOT IMPLEMENTED");
        }
     }
}
