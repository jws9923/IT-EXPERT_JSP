package itexpert.chap13.buy;
import java.util.Enumeration;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.apache.struts.action.ActionForm;
import org.apache.commons.beanutils.PropertyUtils;
import org.apache.log4j.Logger;
import itexpert.chap13.user.UserInfoBean;
import itexpert.chap13.util.DBResource;
import itexpert.chap13.util.ShopConstant;
import itexpert.chap13.exceptions.ShopDAOException;

import javax.naming.InitialContext;
import javax.rmi.PortableRemoteObject;
import itexpert.chap14.ejbs.session.OrderProc;
import itexpert.chap14.ejbs.session.OrderProcHome;
public class EJBOrderDAOImpl implements OrderDAO {
   	String jndiName = "";
	OrderProcHome procHome = null;
    Logger log = Logger.getLogger(EJBOrderDAOImpl.class);

	public EJBOrderDAOImpl(String name) {
		jndiName = name;
	}
	private OrderProc createOrderProc () throws Exception {
		OrderProc ejb = null;
		Object ref;
		try {
			if(procHome != null) {
				ejb = procHome.create();
			} else {
				ref = new InitialContext().lookup(jndiName);
				procHome = (OrderProcHome)PortableRemoteObject.narrow(ref, OrderProcHome.class);
				ejb = procHome.create();
			}
		} catch(Exception e) {
			procHome = null;
			log.error(e.toString());
			throw e;
		}
		return ejb;
	}

    public void orderComplete(HttpServletRequest request) throws ShopDAOException {
        HttpSession session = request.getSession();
        CartBean cart = (CartBean) session.getAttribute("cart");
        UserInfoBean userInfo = (UserInfoBean) session.getAttribute("userInfo");
		try {
			OrderProc procEjb = createOrderProc();
			procEjb.processOrder(cart.getItems(), userInfo.getId());
			cart.emptyCart();
		} catch(Exception e) {
			throw new ShopDAOException(e.getMessage());
		}
	}
}