package itexpert.chap13.buy;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;
import org.apache.commons.beanutils.PropertyUtils;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionError;
import org.apache.log4j.Logger;
import itexpert.chap13.util.ShopConstant;
import itexpert.chap13.user.UserInfoBean;
import itexpert.chap13.exceptions.ShopDAOException;

public class CartAction extends DispatchAction {

    Logger log = Logger.getLogger(CartAction.class);
    
    /**
     * ����īƮ ����
     * ����īƮ ������ Ȯ���ϴ� �������� �̵��ϱ⸸ �Ѵ�.
     */
      public ActionForward view(ActionMapping mapping,
                             ActionForm form,
                             HttpServletRequest request,
                             HttpServletResponse response)
    {
        return mapping.findForward("view");
      }

    /**
     * ����īƮ�� �߰�
     */
      public ActionForward add(ActionMapping mapping,
                          ActionForm form,
                          HttpServletRequest request,
                          HttpServletResponse response)
    {
        HttpSession session = request.getSession();
        CartBean cart = (CartBean) session.getAttribute("cart");
        if (cart == null) {
            cart = new CartBean();
            session.setAttribute("cart", cart);
        }
        try {
            String isbn = (String) PropertyUtils.getSimpleProperty(form, "isbn");
            int quantity = ((Integer) PropertyUtils.getSimpleProperty(form, "quantity")).intValue();
            log.debug("isbn: " + isbn + "/ quantity: " + quantity);
            cart.addItem(new BookBean(isbn, quantity));
        } catch (Exception e) {
            log.error("cart.add", e);
            request.setAttribute("javax.servlet.jsp.jspException", e);
            return mapping.findForward("error");
        }
          return mapping.findForward("view");
      }

    /**
     * ����īƮ ����
     */
      public ActionForward empty(ActionMapping mapping,
                              ActionForm form,
                              HttpServletRequest request,
                              HttpServletResponse response)
    {
        HttpSession session = request.getSession();
        CartBean cart = (CartBean) session.getAttribute("cart");
        cart.emptyCart();
        return mapping.findForward("view");
      }

    /**
     * �ֹ� �Ϸ�
     * ����īƮ�� ����� �͵��� ORDERLIST ���̺��� �Է��Ѵ�.
     */
     public ActionForward finish(ActionMapping mapping,
                              ActionForm form,
                              HttpServletRequest request,
                              HttpServletResponse response)
    {
        HttpSession session = request.getSession();
        UserInfoBean userInfo = (UserInfoBean) session.getAttribute("userInfo");
        // �α����� ���� ���� ���� �ֹ��� �� ���� ������
        // �α����������� main.jsp�� �̵��ϸ� �α����� ���� �ؾ� �Ѵٴ� �޽����� �����ش�.
        if (userInfo == null) {
            ActionErrors errors = new ActionErrors();
            errors.add(ActionErrors.GLOBAL_ERROR,
                            new ActionError("error.login.required"));
            saveErrors(request, errors);
            return mapping.findForward("main");
        }
        try {
            OrderDAO dao = OrderDAOFactory.getDAO(ShopConstant.EJB_DAO);
            dao.orderComplete(request);
        } catch (Exception e) {
            log.error("cart.finish", e);
            request.setAttribute("javax.servlet.jsp.jspException", e);
            return mapping.findForward("error");
        }
        return mapping.findForward("view");
    }
}