package itexpert.chap13.exceptions;

public class ShopDAOException extends Exception {

    public ShopDAOException () {
        super();
    }

    public ShopDAOException (String msg) {
        super(msg);
    }
}
