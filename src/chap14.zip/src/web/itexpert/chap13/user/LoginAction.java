package itexpert.chap13.user;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionError;
import org.apache.log4j.Logger;
import itexpert.chap13.util.ShopConstant;
import itexpert.chap13.exceptions.ShopDAOException;

public class LoginAction extends Action {
    
    Logger log = Logger.getLogger(LoginAction.class);

    public ActionForward execute(ActionMapping mapping,
                                ActionForm form,
                                HttpServletRequest request,
                                HttpServletResponse response)
    {
        try {
            ActionErrors errors = new ActionErrors();
            //UserDAO dao = UserDAOFactory.getDAO(ShopConstant.SHOP_DBTYPE);
            UserDAO dao = UserDAOFactory.getDAO(ShopConstant.EJB_DAO);
            int checkResult = dao.checkUser(form, request, response);
            if (checkResult > 0) {
                switch (checkResult) {
                    case ShopConstant.BLANK_NOTPERMMITED :
                        errors.add(ActionErrors.GLOBAL_ERROR,
                             new ActionError("error.blank.notpermitted"));
                        break;
                    case ShopConstant.ID_NOTEXIST :    // ���̵� �������� �ʴ� ���
                        errors.add(ActionErrors.GLOBAL_ERROR,
                            new ActionError("error.id.notexist"));
                        break;

                    case ShopConstant.PASSWD_MISMATCH : // �н����尡 ��ġ���� �ʴ� ���
                        errors.add(ActionErrors.GLOBAL_ERROR,
                            new ActionError("error.passwd.mismatch"));
                        break;
                    default :
                        errors.add(ActionErrors.GLOBAL_ERROR,
                            new ActionError("error.unknowned"));
                }
            }
            if (!errors.isEmpty()) {
                // request ������ ActionErrors ��ü�� �����Ѵ�.
                saveErrors(request, errors);
                return mapping.getInputForward();
            }
            // ��Ÿ�� ������ ������ ���� �ڵ��̴�.
            // ��Ÿ�� ������ catch �Ͽ� error.jsp���� �޽����� �����ֵ��� �Ѵ�.
            // int i = 1 / 0;
        } catch (Exception e) {
            log.error("login.execute", e);
            request.setAttribute("javax.servlet.jsp.jspException", e);
            return mapping.findForward("error");
        }
        return mapping.findForward("main");
    }
}
