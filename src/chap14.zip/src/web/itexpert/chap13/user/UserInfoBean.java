package itexpert.chap13.user;

public class UserInfoBean implements java.io.Serializable {
    
    private String id;
    private String name;
    private String address;
    private String phone;

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getAddress() {
        return address;
    }    
    
    public String getPhone() {
        return phone;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAddress(String address) {
        this.address = address;
    }    
    
    public void setPhone(String phone) {
        this.phone = phone;
    }
}
