package itexpert.chap13.user;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.struts.action.ActionForm;
import org.apache.commons.beanutils.PropertyUtils;
import org.apache.log4j.Logger;
import itexpert.chap13.util.ShopConstant;
import itexpert.chap13.exceptions.ShopDAOException;

import itexpert.chap14.ejbs.session.UserInfoHome;
import itexpert.chap14.ejbs.session.UserInfo;
import itexpert.chap14.ejbs.session.IDNotFoundException;
import itexpert.chap14.ejbs.session.PasswordMismatchException;

import java.rmi.RemoteException;
import javax.naming.InitialContext;
import javax.rmi.PortableRemoteObject;
public class EJBUserDAOImpl implements UserDAO {
	String jndiName = "";
	Logger log = Logger.getLogger(EJBUserDAOImpl.class);
	UserInfoHome userHome = null;
	public EJBUserDAOImpl(String name) {
		jndiName = name;
	}
	private UserInfo createUserInfo () throws Exception{
		UserInfo ejb = null;
		Object ref;
		try {
			if(userHome != null) {
				ejb = userHome.create();
			} else {
				ref = new InitialContext().lookup(jndiName);
				userHome = (UserInfoHome)PortableRemoteObject.narrow(ref, UserInfoHome.class);
				ejb = userHome.create();
			}
		} catch(Exception e) {
			userHome = null;
			log.error(e.toString());
			throw e;
		}
		return ejb;
	}
	public int checkUser(ActionForm form, HttpServletRequest request, HttpServletResponse response)
	throws ShopDAOException {
		int checkResult = 0;

		try {
			String id = (String) PropertyUtils.getSimpleProperty(form, "id");
			String passwd = (String) PropertyUtils.getSimpleProperty(form, "passwd");
			log.debug(id + "/" + passwd);
			if (id.equals("") || passwd.equals("")) {
				return ShopConstant.BLANK_NOTPERMMITED;
			}
			UserInfo userInfoEjb = createUserInfo();
			UserInfoBean userInfo = userInfoEjb.getUserInfo(id, passwd);
			HttpSession session = request.getSession();
			session.setAttribute("userInfo", userInfo);
		} catch(PasswordMismatchException e) {
			checkResult = ShopConstant.PASSWD_MISMATCH;
		} catch(IDNotFoundException e) {
			checkResult = ShopConstant.ID_NOTEXIST;
		} catch(Exception e) {
			throw new ShopDAOException(e.getMessage());
		}
		return checkResult;
	}

	public int registerUser(ActionForm form,HttpServletRequest request, HttpServletResponse response)
	throws ShopDAOException{
		int checkResult = 0;
		try {
			String id = (String) PropertyUtils.getSimpleProperty(form, "id");
			String passwd = (String) PropertyUtils.getSimpleProperty(form, "passwd");
			String name = (String) PropertyUtils.getSimpleProperty(form, "name");
			String address = (String) PropertyUtils.getSimpleProperty(form, "address");
			String phone = (String) PropertyUtils.getSimpleProperty(form, "phone");
			log.debug(id + "/" + passwd + "/" + name + "/" + address + "/" + phone);
			if (id.equals("") || passwd.equals("") ||
			name.equals("") || address.equals("")
			|| phone.equals("")) {
				return ShopConstant.BLANK_NOTPERMMITED;
			}
			log.debug("default check executed");

			UserInfo userInfoEjb = createUserInfo();
			UserInfoBean userInfo = userInfoEjb.createUser(id, passwd, name, address, phone);
			if(userInfo != null) {
				HttpSession session = request.getSession();
				session.setAttribute("userInfo", userInfo);
			} else {
				checkResult = ShopConstant.ID_DUPLICATE;
			}
		} catch(Exception e) {
			throw new ShopDAOException(e.getMessage());
		}
		return checkResult;
	}
}