package itexpert.chap14.ejbs.session;
import javax.ejb.EJBObject;
import java.rmi.RemoteException;
public interface OrderProc extends EJBObject {
	public void processOrder(java.util.Hashtable books, String userId) throws RemoteException;
}
