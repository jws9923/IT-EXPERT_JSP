package itexpert.chap14.ejbs.session;
import java.rmi.RemoteException;
import javax.ejb.CreateException;
import javax.ejb.EJBHome;
public interface OrderProcHome extends EJBHome {
	public OrderProc create () throws RemoteException, CreateException;
}