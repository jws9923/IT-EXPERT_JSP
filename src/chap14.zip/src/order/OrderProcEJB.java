package itexpert.chap14.ejbs.session;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import javax.ejb.EJBException;
import javax.sql.DataSource;
import itexpert.chap13.buy.BookBean;
import java.util.Enumeration;
import java.util.Hashtable;
import java.sql.*;
import javax.naming.InitialContext;
public class OrderProcEJB implements SessionBean {
	DataSource ds = null;
	static String insertSql = "INSERT INTO orderlist (id, isbn, quantity) VALUES (?, ?, ?)";
	static String  updateSql = "UPDATE books SET remaining=remaining-? WHERE isbn=?";
	public void processOrder(Hashtable books, String userId) {
		Enumeration enum = books.elements();
		BookBean aBook = null;
		Connection conn = null;
		PreparedStatement insertStmt = null, updateStmt = null;
		try {
			conn = ds.getConnection();//use container authentication for datasource
			insertStmt = conn.prepareStatement(insertSql);
			updateStmt = conn.prepareStatement(updateSql);
			while(enum.hasMoreElements()) {
				aBook = (BookBean)enum.nextElement();
				insertStmt.clearParameters();
				insertStmt.setString(1, userId);
				insertStmt.setString(2, aBook.getIsbn());
				insertStmt.setLong(3, aBook.getQuantity());
				insertStmt.executeUpdate();

				updateStmt.clearParameters();
				updateStmt.setLong(1, aBook.getQuantity());
				updateStmt.setString(2, aBook.getIsbn());
				updateStmt.executeUpdate();
			}
			insertStmt.close();
			updateStmt.close();
		} catch(SQLException e) {
			throw new EJBException("Dabase Server problem, Transaction should be rolled back");
		} finally {
			if(conn != null) {
				try {
					conn.close();
				} catch(Exception e) {
					e.printStackTrace();
				}
			}
		}
	}

	public void ejbCreate() {}
	//////// SessionBean interface Implementation /////
	public void ejbRemove() throws EJBException{
		ds = null;
	}
	public void ejbActivate() throws EJBException {}
	public void ejbPassivate() throws EJBException {}
	public void setSessionContext(SessionContext ctx) throws EJBException {
		try {
			ds = (DataSource)new InitialContext().lookup("java:comp/env/jdbc/bookshop");
		} catch(Exception e) {
			throw new EJBException("Couldn't acquire valid datasource " + e.getMessage());
		}
	}
}