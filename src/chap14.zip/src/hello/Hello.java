//Hello.java
package itexpert.chap14.ejbs;
import javax.ejb.EJBObject;
import java.rmi.RemoteException;

public interface Hello extends EJBObject {
	public String sayHello(String name) throws RemoteException ;
}
		