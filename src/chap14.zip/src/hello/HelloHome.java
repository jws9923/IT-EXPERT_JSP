//HelloHome.java 
package itexpert.chap14.ejbs;
import java.rmi.RemoteException;
import javax.ejb.CreateException;
import javax.ejb.EJBHome;
public interface HelloHome extends EJBHome {
	Hello create () throws RemoteException, CreateException;
}