package itexpert.chap14.client;
import javax.naming.InitialContext;
import javax.naming.Context;
import javax.rmi.PortableRemoteObject;
import javax.ejb.*;
import java.rmi.RemoteException;
import javax.naming.NamingException;
import itexpert.chap14.ejbs.*;
import java.util.Properties;
public class HelloEJBClient {
/*
java -Dorg.omg.CORBA.ORBInitialHost=<hostname> (Supply your host name.)
-Dorg.omg.CORBA.ORBInitialPort=1050
-classpath
"ClientStub.jar:$J2EE_HOME/lib/j2ee.jar" Client 
*/	
	public static void main(String [] args) {
		try {
			if(args[1] != null) {
				Properties props = System.getProperties();
				props.put("org.omg.CORBA.ORBInitialHost", args[1]);
				props.put("org.omg.CORBA.ORBInitialPort", "1050");
				System.setProperties(props);
			}
			InitialContext ctx = new InitialContext();	
			Object obj = ctx.lookup("HelloSessionEJB");
			HelloHome home = (HelloHome)PortableRemoteObject.narrow(obj, HelloHome.class);
			Hello hello = home.create();
			String msg = "";
			if(args.length >= 1) 
				msg = hello.sayHello(args[0]);
			else 
				msg = hello.sayHello("Nobody");
			System.out.println(msg);
			hello.remove();
		} catch(NamingException e) {
			System.err.println("Couldn't create proper initial context");
			e.printStackTrace();
		} catch(RemoteException e) {
			System.err.println("Exception occurred during communication ");
			e.printStackTrace();		
		} catch(CreateException e) {
			System.err.println("Couldn't create HelloEJB");
			e.printStackTrace();
		} catch(RemoveException e) {
			e.printStackTrace();
		}
	}
}