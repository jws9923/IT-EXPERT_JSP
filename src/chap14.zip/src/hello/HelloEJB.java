//HelloEJB.java
package itexpert.chap14.ejbs;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import javax.ejb.EJBException;
public class HelloEJB implements SessionBean {
	public String sayHello(String name) {
		return "Hello EJB " + name + "!!" ;  
	}
	public void ejbCreate() {
		System.out.println("ejb create");
	}
	
	//////// SessionBean interface ���� �޽�� /////
	public void ejbRemove() throws EJBException{}
	public void ejbActivate() throws EJBException {}
	public void ejbPassivate() throws EJBException {}
	public void setSessionContext(SessionContext ctx) throws EJBException {}
}