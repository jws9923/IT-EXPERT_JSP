package itexpert.chap14.client;
import itexpert.chap14.ejbs.*;
import java.util.*;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.rmi.PortableRemoteObject;
public class BookEJBClient {
	public static void main(String[] args) {
		try {
			Context initial = new InitialContext();//connect to j2ee server resident in localhost
			Object objref = initial.lookup("BookBmpEJB");
			BookHome home =
			(BookHome)PortableRemoteObject.narrow(objref, BookHome.class);
			try {
				home.create("abcnf-123", "Java Programming Language", "Yang Hooe Suk", 23000);
				System.out.println("created a record with isbn abcnf-123");
				home.create("aaaa-1234", "Java Programming Language", "�ƹ���", 25000);
				System.out.println("created a record with isbn aaaa-1234");
				home.create("abcdef-456", "Perfect Java Server Pages", "Yang Hooe Suk", 33000);
				System.out.println("created a record with isbn abcdef-456");
			} catch(javax.ejb.CreateException e) {
				System.out.println(e.getMessage());
			}
			try {
				Book jpl_1 = home.findByPrimaryKey("abcnf-123");
			} catch(javax.ejb.FinderException e) {
				System.out.println(e.getMessage());
			}
			Collection books  = home.findByTitle("Java Programming Language");
			Iterator it = books.iterator();
			while(it.hasNext()) {
				Object obj = it.next();
				Book b = (Book)PortableRemoteObject.narrow(obj, Book.class);
				System.out.println("Books Found By Title : " + b.getTitle() +" --> isbn: " + b.getIsbn() +
				" author: " + b.getAuthor() + " price: " + b.getPrice());
			}
			Book book1 = null;
			Book book2 = null;
			Book pjsp = null;
			if(args.length > 0 && "delete".equalsIgnoreCase(args[0])) {
				book1 = home.findByPrimaryKey("abcnf-123");
				book2 = home.findByPrimaryKey("aaaa-1234");
				pjsp = home.findByPrimaryKey("abcdef-456");
				book1.remove();
				System.out.println("remove record with isbn abcnf-123");
				book2.remove();
				System.out.println("remove record with isbn aaaa-1234");
				pjsp.remove();
				System.out.println("remove record with isbn abcdef-456");
			}
		} catch (Exception ex) {
			System.err.println("Caught an exception." );
			ex.printStackTrace();
		}
	}
}
