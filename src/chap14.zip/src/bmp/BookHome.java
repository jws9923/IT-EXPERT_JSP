package itexpert.chap14.ejbs;
import java.util.*;
import java.rmi.RemoteException;
import javax.ejb.*;

public interface BookHome extends EJBHome {
	public Book create(String isbn, String title,String author, long price)
	throws RemoteException, CreateException;
	public Book findByPrimaryKey(String isbn) throws FinderException, RemoteException;
	public Collection findByTitle(String title) throws FinderException, RemoteException;

	public Collection findAllBooks() throws FinderException, RemoteException;
}
