package itexpert.chap14.ejbs;
import java.sql.*;
import javax.sql.*;
import java.util.*;
import javax.ejb.*;
import javax.naming.*;

public class BookEJB implements EntityBean {
	private String isbn;
	private String title;
	private String author;
	private long price;
	private EntityContext context;
	private Connection conn;

// Remote Interface Business methods
	public String getIsbn() {
		return isbn;
	}
	public String getTitle() {
		return title;
	}
	public String getAuthor() {
		return author;
	}
	public long getPrice() {
		return price;
	}
	public void setPrice(long price) {
		this.price = price;
	}

	public String ejbCreate(String isbn, String title, String author, long price)
	throws CreateException {
		PreparedStatement stmt = null;
		if (price < 0) {
			throw new CreateException("price�� 0 ���� Ŀ�� �մϴ�.");
		}
		try {
			String query =
			"insert into book (isbn, title, author, price) values (?,?,?,?)";
			//In a production environment this needless trace code should be removed
			 System.out.println(query);
			stmt = conn.prepareStatement(query);
			stmt.setString(1, isbn);
			stmt.setString(2, title);
			stmt.setString(3, author);
			stmt.setLong(4, price);
			stmt.executeUpdate();
		} catch (Exception e) {
			throw new CreateException("ejbCreate: " + e.getMessage());
		} finally {
			if(stmt != null) {
				try {
					stmt.close();
				} catch(Exception e) {
					e.printStackTrace();
					throw new EJBException("DataBase Server problem " + e.getMessage());
				}
			}
		}
		this.isbn = isbn;
		this.title = title;
		this.author = author;
		this.price = price;
		return isbn;
	}

	public String ejbFindByPrimaryKey(String primaryKey)
	throws FinderException {
		boolean result;
		PreparedStatement stmt = null;
		ResultSet rset = null;
		try {
			String query = "select isbn from book where isbn =?";
			System.out.println(query);
			stmt =conn.prepareStatement(query);
			stmt.setString(1, primaryKey);
			rset = stmt.executeQuery();
			result = rset.next();
		} catch (Exception e) {
			throw new EJBException("ejbFindByPrimaryKey: " + e.getMessage());
		} finally {
			if(rset != null) {
				try {
					rset.close();
				} catch(Exception e) {
					e.printStackTrace();
					throw new EJBException("DataBase Server problem " + e.getMessage());
				}
			}
			if(stmt != null) {
				try {
					stmt.close();
				} catch(Exception e) {
					e.printStackTrace();
					throw new EJBException("DataBase Server problem " + e.getMessage());
				}
			}
		}
		if (result) {
			return primaryKey;
		} else {
			throw new ObjectNotFoundException("ejbFindByPrimaryKey: isbn�� " +  primaryKey +
			" �� ���̺� ���ڵ尡 �������� �ʽ��ϴ�.");
		}
	}
	public Collection ejbFindAllBooks() throws FinderException {
		Collection  ret;
		PreparedStatement stmt = null;
		ResultSet rset = null;
		try {
			String query = "select isbn from book";
			stmt = conn.prepareStatement(query);
			rset = stmt.executeQuery();
			ret = new Vector();
			while (rset.next()) {
				String isbn = rset.getString(1);
				ret.add(isbn);
			}
		} catch (Exception e) {
			throw new EJBException("ejbFindAllBooks: " + e.getMessage());
		} finally {
			if(rset != null) {
				try {
					rset.close();
				} catch(Exception e) {
					e.printStackTrace();
					throw new EJBException("DataBase Server problem " + e.getMessage());
				}
			}
			if(stmt != null) {
				try {
					stmt.close();
				} catch(Exception e) {
					e.printStackTrace();
					throw new EJBException("DataBase Server problem " + e.getMessage());
				}
			}
		}
		return ret;
	}
	public Collection ejbFindByTitle(String title) throws FinderException {
		Collection  ret;
		PreparedStatement stmt = null;
		ResultSet rset = null;
		try {
			String query = "select isbn from book where title =?";
			stmt = conn.prepareStatement(query);
			stmt.setString(1, title);
			rset = stmt.executeQuery();
			ret = new Vector();
			while (rset.next()) {
				String isbn = rset.getString(1);
				ret.add(isbn);
			}
		} catch (Exception e) {
			throw new EJBException("ejbFindByTitle: " + e.getMessage());
		} finally {
			if(rset != null) {
				try {
					rset.close();
				} catch(Exception e) {
					e.printStackTrace();
					throw new EJBException("DataBase Server problem " + e.getMessage());
				}
			}
			if(stmt != null) {
				try {
					stmt.close();
				} catch(Exception e) {
					e.printStackTrace();
					throw new EJBException("DataBase Server problem " + e.getMessage());
				}
			}
		}
		if (ret.isEmpty()) {
			throw new ObjectNotFoundException("ejbFindByTitle: title �� "
			+  title + "�� ���ڵ尡 �������� �ʽ��ϴ�.");
		} else {
			return ret;
		}
	}

	public void ejbRemove() {
		PreparedStatement stmt = null;
		try {
			String query =	"delete from book where isbn =?";
			stmt = conn.prepareStatement(query);
			stmt.setString(1, isbn);
			stmt.executeUpdate();
		} catch (Exception e) {
			throw new EJBException("ejbRemove: " + e.getMessage());
		} finally {
			if(stmt != null) {
				try {
					stmt.close();
				} catch(Exception e) {
					e.printStackTrace();
					throw new EJBException("DataBase Server problem " + e.getMessage());
				}
			}
		}
	}
	public void setEntityContext(EntityContext context) {
		this.context = context;
		try {
			InitialContext ic = new InitialContext();
			DataSource ds = (DataSource) ic.lookup("java:comp/env/jdbc/bookshop");
			conn =  ds.getConnection();//will use Container Authentication
		} catch (Exception e) {
			throw new EJBException("������ ���̽� Ŀ�ؼ� ����! " + e.getMessage());
		}
	}
	public void unsetEntityContext() {
		try {
			conn.close();
		} catch (SQLException e) {
			throw new EJBException("unsetEntityContext: " + e.getMessage());
		}
	}
	public void ejbActivate() {
		isbn = (String)context.getPrimaryKey();
	}
	public void ejbPassivate() {
		isbn = null;
	}
	public void ejbLoad() {
		PreparedStatement stmt = null;
		ResultSet rset = null;
		try {
			String query = "select title, author, price " +
			"from book where isbn =?";
			stmt =
			conn.prepareStatement(query);
			stmt.setString(1, isbn);
			rset = stmt.executeQuery();
			if (rset.next()) {
				this.title = rset.getString(1);
				this.author = rset.getString(2);
				this.price = rset.getLong(3);
			} else {
				throw new NoSuchEntityException("ejbLoad: isbn�� " + isbn +
				" �� �����ͺ��̽� ���ڵ尡 �������� �ʽ��ϴ�.");
			}
		} catch (Exception e) {
			throw new EJBException("ejbLoad: " + e.getMessage());
		} finally {
			if(rset != null) {
				try {
					rset.close();
				} catch(Exception e) {
					e.printStackTrace();
					throw new EJBException("DataBase Server problem " + e.getMessage());
				}
			}
			if(stmt != null) {
				try {
					stmt.close();
				} catch(Exception e) {
					e.printStackTrace();
					throw new EJBException("DataBase Server problem " + e.getMessage());
				}
			}
		}
	}
	public void ejbStore() {
		PreparedStatement stmt = null;
		try {
			String query = "update book set title =? ,author =? ,price=? where isbn=?";
			stmt = conn.prepareStatement(query);
			stmt.setString(1, title);
			stmt.setString(2, author);
			stmt.setLong(3, price);
			stmt.setString(4, isbn);
			int rowCount = stmt.executeUpdate();
			if (rowCount == 0) {
				throw new EJBException("ejbStore: ��ƼƼ ���� ���������� �����ͺ��̽��� �����ϴµ� ���� ");
			}
		} catch (Exception e) {
			throw new EJBException("ejbStore: " + e.getMessage());
		} finally {
			if(stmt != null) {
				try {
					stmt.close();
				} catch(Exception e) {
					e.printStackTrace();
					throw new EJBException("DataBase Server problem " + e.getMessage());
				}
			}
		}
	}
	public void ejbPostCreate(String isbn, String title, String author, long price) {}
}