package itexpert.chap14.ejbs;
import javax.ejb.EJBObject;
import java.rmi.RemoteException;

public interface Book extends EJBObject {
	public String getIsbn()throws RemoteException;
	public String getTitle()throws RemoteException;
	public String getAuthor () throws RemoteException;
	public long getPrice()throws RemoteException;

	public void setPrice(long price) throws RemoteException;
}