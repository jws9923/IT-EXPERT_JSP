package itexpert.chap14.ejbs.entity;
import java.sql.*;
import javax.sql.*;
import java.util.*;
import javax.ejb.*;
import javax.naming.*;

public abstract class MemberEJB implements EntityBean {
	EntityContext context = null;
	// Container-Managed Persistence Field Definitions
	public abstract String getId();
	public abstract String getPasswd();
	public abstract String getName ();
	public abstract String getAddress();
	public abstract String getPhone();

	public abstract void setId(String id);
	public abstract void setPasswd(String pass);
	public abstract void setName(String name);
	public abstract void setAddress(String addr);
	public abstract void setPhone(String phone);

	public String ejbCreate(String id, String passwd, String name) throws CreateException {
		setId(id);
		setPasswd(passwd);
		setName(name);
		setAddress("");
		setPhone("");
		return null;
	}
	public String ejbCreate(String id, String passwd, String name, String addr, String phone)
	throws CreateException {
		setId(id);
		setPasswd(passwd);
		setName(name);
		setAddress(addr);
		setPhone(phone);
		return null;
	}
	public void ejbPostCreate(String id, String passwd, String name, String addr, String phone){}
	public void ejbPostCreate(String id, String passwd, String name){}
	// In CMP , All Finder Methods are defined only in Home interface,
	// Container cares actual implementation of those methods

	public void ejbRemove() {}
	public void setEntityContext(EntityContext context) {
		this.context = context;
	}
	public void unsetEntityContext() {}
	public void ejbActivate() {}
	public void ejbPassivate() {}
	public void ejbLoad() {}
	public void ejbStore() {}
}