package itexpert.chap14.ejbs.entity;
import java.util.*;
import javax.ejb.*;
public interface LocalMemberHome extends EJBLocalHome {
	public LocalMember create(String id, String passwd, String name, String addr, String phone) throws CreateException;
	public LocalMember create(String primaryKey , String passwd, String name) throws CreateException;
	public LocalMember findByPrimaryKey(String primaryKey) throws FinderException;
	public Collection findByName(String name) throws FinderException;
}
