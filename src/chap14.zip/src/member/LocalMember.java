package itexpert.chap14.ejbs.entity;
public interface LocalMember extends javax.ejb.EJBLocalObject {
	public String getId();
	public String getPasswd();
	public String getName ();
	public String getAddress();
	public String getPhone();

	public void setPasswd(String pass);
	public void setName(String name);
	public void setAddress(String addr);
	public void setPhone(String phone);
	//LocalMemberEJB has no relationship field.
}