package itexpert.chap14.ejbs;
public interface LocalBook extends javax.ejb.EJBLocalObject {
	public String getIsbn();
	public String getTitle();
	public String getAuthor ();
	public long getPrice();
	public void setPrice(long price);
	//LocalBookEJB has no relationship field.
}