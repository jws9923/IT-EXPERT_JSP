package itexpert.chap14.ejbs;
import java.sql.*;
import javax.sql.*;
import java.util.*;
import javax.ejb.*;
import javax.naming.*;

public abstract class BookCmpEJB implements EntityBean {
	EntityContext context = null;
	// Container-Managed Persistence Field Definitions
	public abstract String getIsbn();
	public abstract String getTitle();
	public abstract String getAuthor();
	public abstract long getPrice();
	public abstract void setIsbn(String isbn);
	public abstract void setTitle(String title);
	public abstract void setAuthor(String author);
	public abstract void setPrice(long price);

	public String ejbCreate(String isbn, String title, String author, long price)
	throws CreateException {
		setIsbn(isbn);
		setTitle(title);
		setAuthor(author);
		setPrice(price);
		return null;
	}
	public void ejbPostCreate(String isbn, String title, String author, long price) {}
	// In CMP , All Finder Methods are defined only in Home interface,
	// Container cares actual implementation of those methods

	public void ejbRemove() {}
	public void setEntityContext(EntityContext context) {
		this.context = context;
	}
	public void unsetEntityContext() {}
	public void ejbActivate() {}
	public void ejbPassivate() {}
	public void ejbLoad() {}
	public void ejbStore() {}
}