package itexpert.chap14.ejbs;
import java.util.*;
import javax.ejb.*;

public interface LocalBookHome extends EJBLocalHome {
	public LocalBook create(String isbn, String title,String author, long price)
	throws CreateException;
	public LocalBook findByPrimaryKey(String isbn) throws FinderException;
	public Collection findByTitle(String title) throws FinderException;
	public Collection findAllBooks() throws FinderException;
}
