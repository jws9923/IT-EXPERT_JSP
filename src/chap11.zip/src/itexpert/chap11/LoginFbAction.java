package itexpert.chap11;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionError;
import org.apache.commons.beanutils.PropertyUtils;

public class LoginFbAction extends Action {

    public ActionForward execute(ActionMapping mapping, 
                                ActionForm form, 
                                HttpServletRequest request, 
                                HttpServletResponse response)
    {
        String next = "main";
        ActionErrors errors = new ActionErrors();
        try {
            /** 3 ������ Commons BeanUtils�� ����� �� �Ʒ� �� ���ΰ� ������ ���� **/
            // LoginForm loginForm = (LoginForm) form;
            // String id = loginForm.getId();
            // String passwd = loginForm.getPasswd();
            String id = (String) PropertyUtils.getSimpleProperty(form, "id");
            String passwd = (String) PropertyUtils.getSimpleProperty(form, "passwd");

               String[] idList = {"admin", "xpert"};
            String[] passwdList = {"okjsp11", "aboutjsp22"};
            int[] gradeList = {1, 2};
            
            int idx = -1;            
            for (int i=0; i<idList.length; i++) {
                if (idList[i].equals(id)) {
                    idx = i;
                    break;
                }
            }
            if (idx > -1) {
                if (passwdList[idx].equals(passwd)) {
                    if (gradeList[idx] == 1)
                        next = "admin";
                    UserSession user = new UserSession();
                    user.setId(id);
                    user.setGrade(gradeList[idx]);
                    HttpSession session = request.getSession();
                    session.setAttribute("user", user);
                } else {
                    errors.add(ActionErrors.GLOBAL_ERROR,
                           new ActionError("error.passwd.mismatch"));
                }
            } else {
                   errors.add(ActionErrors.GLOBAL_ERROR,
                    new ActionError("error.id.notexist"));
            }    
            if (!errors.isEmpty()) {
                saveErrors(request, errors);
                return mapping.getInputForward();
            }

        } catch(Exception e) {
            e.printStackTrace();
            request.setAttribute("javax.servlet.jsp.jspException", e);
            next = "error";
        }
        return mapping.findForward(next);
    }
}