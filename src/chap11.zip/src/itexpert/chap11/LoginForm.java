package itexpert.chap11;

import javax.servlet.http.HttpServletRequest;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionError;

public final class LoginForm extends ActionForm {

    private String id;
    private String passwd;
    
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPasswd() {
        return passwd;
    }

    public void setPasswd(String passwd) {
        this.passwd = passwd;
    }    

	/**
	 * ���ǿ� ����Ǿ� �ִ� LoginForm�� �ʱ�ȭ�Ѵ�.
	 */
    public void reset(ActionMapping mapping, HttpServletRequest request) {
        this.id = null;
        this.passwd = null;
    }

    /**
     * ID�� �н����带 4�� �̻� �Է��ؾ߸� ������ �߻����� �ʴ´�.
     */
    public ActionErrors validate(ActionMapping mapping,
                                 HttpServletRequest request) {
        ActionErrors errors = new ActionErrors();
        if (id == null || id.trim().length() < 4) {
            errors.add("id", new ActionError("error.id.tooshort"));
        }
        if (passwd== null || passwd.trim().length() < 4) {
            errors.add("password", new ActionError("error.passwd.tooshort"));
        }
        return errors;
    }
}