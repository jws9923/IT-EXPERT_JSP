package itexpert.chap12;

public class Person {

    private int group;
    private String name;
    private String email;
    private String phone;
    private String addr;
    private String memo;

    public String getAddr() {
        return addr;
    }

    public String getEmail() {
        return email;
    }

    public int getGroup() {
        return group;
    }

    public String getMemo() {
        return memo;
    }

    public String getName() {
        return name;
    }

    public String getPhone() {
        return phone;
    }

    public void setAddr(String addr) {
        this.addr = addr;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setGroup(int group) {
        this.group = group;
    }

    public void setMemo(String memo) {
        this.memo = memo;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }
}
