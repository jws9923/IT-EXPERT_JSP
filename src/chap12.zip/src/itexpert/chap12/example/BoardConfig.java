package itexpert.chap12.example;

public class BoardConfig {

    private String title;
    private String skin;
    private int level;
    private String db;    

    public String getDb() {
        return db;
    }

    public int getLevel() {
        return level;
    }

    public String getSkin() {
        return skin;
    }

    public String getTitle() {
        return title;
    }

    public void setDb(String db) {
        this.db = db;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public void setSkin(String skin) {
        this.skin = skin;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}