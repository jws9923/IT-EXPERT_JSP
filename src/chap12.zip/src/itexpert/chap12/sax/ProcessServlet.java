package itexpert.chap12.sax;

import java.util.ArrayList;
import java.io.IOException;
import java.io.InputStream;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.xml.sax.InputSource;
import org.xml.sax.helpers.XMLReaderFactory;
import org.xml.sax.XMLReader;
import org.xml.sax.SAXException;

public class ProcessServlet extends HttpServlet {

    public void doGet(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
        doPost(request, response);
    }

    public void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
        ArrayList list = null;
        InputStream stream    = getServletContext().getResourceAsStream("/WEB-INF/xml/addressbook.xml");
        AddressBookHandler handler = new AddressBookHandler();
        try {
            InputSource source = new InputSource(stream); 
            XMLReader reader = XMLReaderFactory.createXMLReader("org.apache.xerces.parsers.SAXParser");
            // handler�� ContentHandler�� ���
            reader.setContentHandler(handler);
            // handler�� ErrorHandler�� ���
            reader.setErrorHandler(handler);
            reader.parse(source);
            list = handler.getAddressBook(); // �Ľ��� ��� ����Ʈ�� ������
            request.setAttribute("addressbook", list); // request ������ list�� ����
            // �ּҷ� �����͸� ������ ������ /sax/addressbook.jsp�� ������ �̵�
            getServletContext().getRequestDispatcher("/sax/addressbook.jsp").forward(request, response);
        } catch (SAXException e) {
            throw new ServletException(e.toString());
        } catch (Exception e) {
            throw new ServletException(e.toString());
        }
    }
}