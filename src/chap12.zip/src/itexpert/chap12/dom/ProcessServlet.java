package itexpert.chap12.dom;

import java.util.ArrayList;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.FileOutputStream;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Text;
import org.w3c.dom.Attr;
import org.w3c.dom.NodeList;
import org.apache.xerces.parsers.DOMParser;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.apache.xml.serialize.OutputFormat;
import org.apache.xml.serialize.XMLSerializer;
import itexpert.chap12.Person;

public class ProcessServlet extends HttpServlet {

    // addressbook.xml ������ ���
    private static final String path = "/WEB-INF/xml/addressbook.xml";

    public void doGet(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
        if (request.getParameter("action") == null ) {
            listAction(request, response); // ����Ʈ
        } else if (request.getParameter("action").equals("view")) {
            viewAction(request, response); // ����(����)
        } else {
            doPost(request, response); // ����ȭ �ʿ��� action
        }
    }

    public void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
        try {
            Document doc = parseXML();
            // addressbook ��Ҹ� ���Ѵ�.
            Element root = doc.getDocumentElement();
            NodeList personList = doc.getElementsByTagName("person");
            if (request.getParameter("action").equals("insert")) {
                Element personElement = doc.createElement("person");

                // ��û �Ķ���Ϳ��� �Ӽ� ���� Text ��带 �����Ѵ�.
                Attr groupAttr = doc.createAttribute("group");
                groupAttr.setValue(request.getParameter("group"));
                Text nameText = doc.createTextNode(request.getParameter("name"));
                Text emailText = doc.createTextNode(request.getParameter("email"));
                Text phoneText = doc.createTextNode(request.getParameter("phone"));
                Text addrText = doc.createTextNode(request.getParameter("addr"));
                Text memoText = doc.createTextNode(request.getParameter("memo"));

                // person ����� �ڽ� ��ҵ��� �����Ѵ�.
                Element nameElement = doc.createElement("name");
                Element emailElement = doc.createElement("email");
                Element phoneElement = doc.createElement("phone");
                Element addrElement = doc.createElement("addr");
                Element memoElement = doc.createElement("memo");

                // person ����� �ڽ� ��ҵ鿡 Text ��带 �߰��Ѵ�.
                nameElement.appendChild(nameText);
                emailElement.appendChild(emailText);
                phoneElement.appendChild(phoneText);
                addrElement.appendChild(addrText);
                memoElement.appendChild(memoText);
                
                // person ��ҿ� �Ӽ��� �ڽ� ��ҵ��� �߰��Ѵ�.
                personElement.setAttributeNode(groupAttr);
                personElement.appendChild(nameElement);
                personElement.appendChild(emailElement);
                personElement.appendChild(phoneElement);
                personElement.appendChild(addrElement);
                personElement.appendChild(memoElement);

                // addressbook ��ҿ� person �ڽ� ��Ҹ� �߰��Ѵ�.
                root.appendChild(personElement);
            } else if (request.getParameter("action").equals("update")) {
                int num = Integer.parseInt(request.getParameter("num"));
                // ���� ���
                Element oldElement = (Element) personList.item(num);

                // ���� �Էµ� ���
                Element personElement = doc.createElement("person");
                Attr groupAttr = doc.createAttribute("group");
                groupAttr.setValue(request.getParameter("group"));
                Text nameText = doc.createTextNode(request.getParameter("name"));
                Text emailText = doc.createTextNode(request.getParameter("email"));
                Text phoneText = doc.createTextNode(request.getParameter("phone"));
                Text addrText = doc.createTextNode(request.getParameter("addr"));
                Text memoText = doc.createTextNode(request.getParameter("memo"));
                
                Element nameElement = doc.createElement("name");
                Element emailElement = doc.createElement("email");
                Element phoneElement = doc.createElement("phone");
                Element addrElement = doc.createElement("addr");
                Element memoElement = doc.createElement("memo");
                
                nameElement.appendChild(nameText);
                emailElement.appendChild(emailText);
                phoneElement.appendChild(phoneText);
                addrElement.appendChild(addrText);
                memoElement.appendChild(memoText);
                personElement.setAttributeNode(groupAttr);
                personElement.appendChild(nameElement);
                personElement.appendChild(emailElement);
                personElement.appendChild(phoneElement);
                personElement.appendChild(addrElement);
                personElement.appendChild(memoElement);

                // ���� ��� ��ġ�� ���ο� ��Ҹ� �ٲپ� �ִ´�.
                root.replaceChild(personElement, oldElement);
            } else if (request.getParameter("action").equals("delete")) {
                int num = Integer.parseInt(request.getParameter("num"));
                Element element = (Element) personList.item(num);
                root.removeChild(element);
            }
            String outPath = getServletContext().getRealPath("") + path;
            OutputStream outputStream = new FileOutputStream(outPath);
            OutputFormat format  = new OutputFormat(doc, "euc-kr", true);
            XMLSerializer serial = new XMLSerializer(outputStream, format );
            serial.serialize(doc);
            getServletContext().getRequestDispatcher("/dom/processed.jsp").forward(request, response);
        } catch (SAXException e) {
            throw new ServletException(e.toString());
        } catch (Exception e) {
            throw new ServletException(e.toString());
        }
    }

    private void listAction(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
        ArrayList list = new ArrayList();
        try {
            Document doc = parseXML();
            // person ��� ����Ʈ�� �����´�.
            NodeList personList = doc.getElementsByTagName("person");
            Person person = null;
            Element element = null;
            for (int i = 0; i < personList.getLength(); i++) {
                person = new Person();
                // personList ��� ���������� �ϳ��� person ��Ҹ� �����´�.
                element = (Element) personList.item(i);
                person.setGroup(Integer.parseInt(element.getAttribute("group")));
                person.setName(element.getElementsByTagName("name").item(0)
                            .getFirstChild().getNodeValue());
                person.setEmail(element.getElementsByTagName("email").item(0)
                            .getFirstChild().getNodeValue());
                person.setPhone(element.getElementsByTagName("phone").item(0)
                            .getFirstChild().getNodeValue());
                person.setAddr(element.getElementsByTagName("addr").item(0)
                            .getFirstChild().getNodeValue());
                person.setMemo(element.getElementsByTagName("memo").item(0)
                            .getFirstChild().getNodeValue());
                // ArrayList�� person ��ü�� �߰��Ѵ�.
                list.add(person);
            }
            request.setAttribute("addressbook", list);
            getServletContext().getRequestDispatcher("/dom/addressbook.jsp").forward(request, response);
        } catch (SAXException e) {
            throw new ServletException(e.toString());
        } catch (Exception e) {
            throw new ServletException(e.toString());
        }
    }

    private void viewAction(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
        int num = Integer.parseInt(request.getParameter("num"));
        try {
            Document doc = parseXML();
            NodeList personList = doc.getElementsByTagName("person");
            Person person = new Person();
            Element element = (Element) personList.item(num);
            person.setGroup(Integer.parseInt(element.getAttribute("group")));
            person.setName(element.getElementsByTagName("name").item(0)
                        .getFirstChild().getNodeValue());
            person.setEmail(element.getElementsByTagName("email").item(0)
                        .getFirstChild().getNodeValue());
            person.setPhone(element.getElementsByTagName("phone").item(0)
                        .getFirstChild().getNodeValue());
            person.setAddr(element.getElementsByTagName("addr").item(0)
                        .getFirstChild().getNodeValue());
            person.setMemo(element.getElementsByTagName("memo").item(0)
                        .getFirstChild().getNodeValue());
            request.setAttribute("person", person);
            getServletContext().getRequestDispatcher("/dom/addressForm.jsp").forward(request, response);
        } catch (SAXException e) {
            throw new ServletException(e.toString());
        } catch (Exception e) {
            throw new ServletException(e.toString());
        }
    }

    private Document parseXML() throws SAXException, IOException {
        Document doc = null;
        InputStream inputStream = getServletContext().getResourceAsStream(path);
        InputSource source = new InputSource(inputStream); 
        DOMParser parser = new DOMParser(); 
        parser.parse(source);
        doc = parser.getDocument();
        return doc;
    }
}