package itexpert.chap12.jdom;

import java.util.Iterator;
import java.util.List;
import java.util.ArrayList;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.FileOutputStream;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.xml.sax.InputSource;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.Attribute;
import org.jdom.input.SAXBuilder;
import org.jdom.output.XMLOutputter;
import org.jdom.JDOMException;
import itexpert.chap12.Person;

public class ProcessServlet extends HttpServlet {

    private static final String path = "/WEB-INF/xml/addressbook.xml";

    public void doGet(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
        if (request.getParameter("action") == null ) {
            listAction(request, response);
        } else if (request.getParameter("action").equals("view")) {
            viewAction(request, response);
        } else {
            doPost(request, response);
        }
    }

    public void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
        try {
            Document doc = parseXML();
            Element root = doc.getRootElement();
            List elements = root.getChildren();
            if (request.getParameter("action").equals("insert")) {
                Element personElement = new Element("person");
                personElement.setAttribute(new Attribute("group", request.getParameter("group")));
                personElement.addContent(new Element("name").setText(request.getParameter("name")));
                personElement.addContent(new Element("email").setText(request.getParameter("email")));
                personElement.addContent(new Element("phone").setText(request.getParameter("phone")));
                personElement.addContent(new Element("addr").setText(request.getParameter("addr")));
                personElement.addContent(new Element("memo").setText(request.getParameter("memo")));

                root.addContent(personElement);
            } else if (request.getParameter("action").equals("update")) {
                int num = Integer.parseInt(request.getParameter("num"));
                Element element = (Element) elements.get(num); 
                element.getAttribute("group").setValue(request.getParameter("group"));
                element.getChild("name").setText(request.getParameter("name"));
                element.getChild("email").setText(request.getParameter("email"));
                element.getChild("phone").setText(request.getParameter("phone"));
                element.getChild("addr").setText(request.getParameter("addr"));
                element.getChild("memo").setText(request.getParameter("memo"));
            } else if (request.getParameter("action").equals("delete")) {
                int num = Integer.parseInt(request.getParameter("num"));
                Element element = (Element) elements.get(num); 
                root.removeContent(element);
            }
            String outPath = getServletContext().getRealPath("") + path;
            OutputStream outputStream = new FileOutputStream(outPath);
            XMLOutputter outputter = new XMLOutputter("  ", true, "euc-kr");
            outputter.output(doc,outputStream);
            outputStream.close();
            getServletContext().getRequestDispatcher("/jdom/processed.jsp").forward(request, response);
        } catch (JDOMException e) {
            throw new ServletException(e.toString());
        }
    }
    
    private void listAction(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
        ArrayList list = new ArrayList();
        try {
            Document doc = parseXML();
            List elements = doc.getRootElement().getChildren();
            Person person = null;
            Element element = null;
            for (Iterator i = elements.iterator(); i.hasNext(); ) {
                person = new Person();
                element = (Element) i.next();
                person.setGroup(Integer.parseInt(element.getAttribute("group").getValue()));
                person.setName(element.getChild("name").getTextTrim());
                person.setEmail(element.getChild("email").getTextTrim());
                person.setPhone(element.getChild("phone").getTextTrim());
                person.setAddr(element.getChild("addr").getTextTrim());
                person.setMemo(element.getChild("memo").getTextTrim());
                list.add(person);
            }
            request.setAttribute("addressbook", list);
            getServletContext().getRequestDispatcher("/jdom/addressbook.jsp").forward(request, response);
        } catch (JDOMException e) {
            throw new ServletException(e.toString());
        }
    }

    private void viewAction(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
        int num = Integer.parseInt(request.getParameter("num"));
        try {
            Document doc = parseXML();
            List elements = doc.getRootElement().getChildren();
            Person person = new Person();
            Element element = (Element) elements.get(num); 
            person.setGroup(Integer.parseInt(element.getAttribute("group").getValue()));
            person.setName(element.getChild("name").getTextTrim());
            person.setEmail(element.getChild("email").getTextTrim());
            person.setPhone(element.getChild("phone").getTextTrim());
            person.setAddr(element.getChild("addr").getTextTrim());
            person.setMemo(element.getChild("memo").getTextTrim());
            request.setAttribute("person", person);
            getServletContext().getRequestDispatcher("/jdom/AddressForm.jsp").forward(request, response);
        } catch (JDOMException e) {
            throw new ServletException(e.toString());
        } 
    }

    private Document parseXML() throws JDOMException {
        InputStream inputStream= getServletContext().getResourceAsStream(path);
        InputSource source = new InputSource(inputStream); 
        SAXBuilder builder = new SAXBuilder();
        return builder.build(source);
    }
}