package itexpert.chap12.xslt;

import java.io.IOException;
import java.io.File;
import java.io.ByteArrayOutputStream;

import javax.servlet.ServletOutputStream;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.xml.sax.InputSource;
import org.xml.sax.XMLReader;

import org.apache.fop.apps.Driver;
import org.apache.fop.apps.Version;
import org.apache.fop.apps.Options;
import org.apache.fop.apps.XSLTInputHandler;
import org.apache.fop.messaging.MessageHandler;

import org.apache.avalon.framework.logger.ConsoleLogger;
import org.apache.avalon.framework.logger.Logger;

public class FopServlet extends HttpServlet {

    private static final String XML_PATH = "/WEB-INF/xml/addressbook.xml";
    private static final String XSL_PATH = "/WEB-INF/xml/addressbook.fo.xsl";
    private static final String CONFIG_PATH = "/WEB-INF/xml/userconfig.xml";
    Logger log = null;

    public void doGet(HttpServletRequest request, HttpServletResponse response) 
        throws ServletException, IOException 
    {
        if (log == null) {
             log = new ConsoleLogger(ConsoleLogger.LEVEL_DEBUG);
            MessageHandler.setScreenLogger(log);
        }
        ServletOutputStream output = response.getOutputStream();
        String rootPath = getServletContext().getRealPath("");

        try {
            XSLTInputHandler input = new XSLTInputHandler(new File(rootPath + XML_PATH), new File(rootPath + XSL_PATH));
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            response.setContentType("application/pdf");
            // userconfig.xml�� ����� Cyberbit ��Ʈ ������ �����´�.
            Options options = new Options(new File(rootPath + CONFIG_PATH));
            Driver driver = new Driver();
            // PDF�� �����ϸ鼭 �α׸� �����.
            driver.setLogger(log);
            driver.setRenderer(Driver.RENDER_PDF);
            driver.setOutputStream(out);
            driver.render(input.getParser(), input.getInputSource());
            byte[] content = out.toByteArray();
            response.setContentLength(content.length);
            output.write(content);
            output.flush(); 
        } catch (Exception e) {
            log.error("exception: " + e.getMessage());
            throw new ServletException(e);
        }
    }
}