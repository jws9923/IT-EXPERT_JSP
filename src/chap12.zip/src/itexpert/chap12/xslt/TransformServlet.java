package itexpert.chap12.xslt;

import java.io.File;
import java.io.PrintWriter;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import javax.xml.transform.TransformerFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.Source;
import javax.xml.transform.stream.StreamSource;
import javax.xml.transform.stream.StreamResult;

public class TransformServlet extends HttpServlet {

    private static final String XML_PATH = "/WEB-INF/xml/addressbook.xml";
    private static final String XSL_PATH = "/WEB-INF/xml/addressbook.xsl";

    public void doGet(HttpServletRequest request, HttpServletResponse response) 
        throws ServletException, IOException {
        doPost(request, response);
    }

    public void doPost(HttpServletRequest request, HttpServletResponse response) 
        throws ServletException, IOException {
        response.setContentType("text/html; charset=euc-kr");
        PrintWriter out = response.getWriter();
        String rootPath = getServletContext().getRealPath("");
        try {
            TransformerFactory factory = TransformerFactory.newInstance();
            Source xmlSource = new StreamSource(new File(rootPath + XML_PATH));
            Source xslSource = new StreamSource(new File(rootPath + XSL_PATH));
            // Transformer ��ü�� �����Ѵ�.
            Transformer transformer = factory.newTransformer(xslSource);
            // ��ȯ�� �����Ͽ� ����� response�� ������.
            transformer.transform(xmlSource, new StreamResult(out));
        } catch (Exception e) {
            throw new ServletException(e.toString());
        }
        out.close();
    }
}